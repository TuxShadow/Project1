#!/bin/bash

echo "++++++++++++++++++++++++++++++++++++++++++++++"
echo "Tahap Pengembangan						 +"
echo "Programmed By Tux_Shadow And Shakespeare     +"
echo "++++++++++++++++++++++++++++++++++++++++++++++"
echo " "
echo " "
echo "1.Update Sistem"
echo "2.Hacking WiFi"
echo "3.Buka Browser"
echo "4.Zenmap"
echo "5.MsfConsole"
echo "6.wifite"
echo "7.Setoolkit"
echo "8.Ettercap"
echo "9.Edit Repository"
echo "10.Informasi Tentang Sistem"
echo "11.Honeypot"
echo "12.Routersploit"
echo "13.Ufonet"
echo "14.Scan Web"
echo "15.Information Gathering"
echo "16.Start Network Manager"
echo "17.OJS Shell Finder By idx"
echo "18.SQLi"

echo "Masukkan Pilihan : "
read pilihan

case $pilihan in
	1)sudo apt-get update && ./Tools.sh;;
	2)sudo ./linset && ./Tools.sh;;
	3)sudo firefox && ./Tools.sh;;
	4)sudo zenmap && ./Tools.sh;;
	5)sudo msfconsole && ./Tools.sh;;
	6)sudo wifite && ./Tools.sh;;
	7)sudo setoolkit && ./Tools.sh;;
	8)sudo ettercap -G && ./Tools.sh;;
	9)sudo nano /etc/apt/sources.list && ./Tools.sh;;
	10)uname -a && ./Tools.sh;;
	11)sudo ruby pentbox.rb && ./Tools.sh;;
	12)sudo python rsf.py && ./Tools.sh;;
	13)sudo ./ufonet --gui && ./Tools.sh;;
	14)echo "Masukkan Target : " && read target && clear && uniscan -u $target --qweds && ./Tools.sh;;
	15)echo "Masukkan Target : " && read web && clear && whatweb $web && ./Tools.sh;;
	16)sudo service network-manager start && ./Tools.sh;;
	17)echo "Masukkan url " && read url && echo "Masukkan Nama File " && read file && cd OJS && php ojs.php $url $file && ./Tools.sh;;
	18)echo "Masukkan target" && read sqli && sqlmap -u $sqli --dbs;;
	
	esac
	