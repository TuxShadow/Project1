How To Run It :
chmod 777 ./Tools.sh
./Tools.sh

Jika Ada yang tidak bekerja berarti tools nya belum terinstall :)
Telah di uji coba di OS kali linux 2017